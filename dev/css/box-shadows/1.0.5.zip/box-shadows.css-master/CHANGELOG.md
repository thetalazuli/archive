# Changes to box-shadows.css

### 1.0.5 (September 24, 2018)

* Removed prefixes: -webkit-, -moz-, -ms-
* Added file box-shadows.scss
* Added file box-shadows.css.map

### 1.0.4 (June 18, 2018)

* The number of blocks is increased.
* Сhanged the order of blocks.

### 1.0.3 (June 02, 2018)

* Minor changes to the repository

### 1.0.2 (May 28, 2018)

* Added blurred shadows (сollection increased to 53 blocks)

### 1.0.1 (May 15, 2018)

* Increased from 21 to 45 numbers.
* Сhanged the order of blocks.

### 1.0.01 (May 13, 2018)
(Only the notable changes since public release)
* Increased from 12 to 21 examples.

### 1.0.0 (May 11, 2018)
* Public release.
