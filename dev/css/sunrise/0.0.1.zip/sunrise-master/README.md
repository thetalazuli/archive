# sunrise

A quick experiment; I took a video of a sunrise from the internet, sampled some colors, and made them into animated CSS gradients.

Check it out here: https://stubailo.github.io/sunrise/
