xdescribe("UI Search", function() {

  moduleTests({
    module    : 'search',
    element   : '.ui.search'
  });

});