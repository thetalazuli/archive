---
name: 🚀 Feature Request
about: Suggest a new feature

---

# Feature Request

## Description
Explain what you want in great detail

## Example

## Testcase (when possible)
<!-- Fork https://jsfiddle.net/31d6y7mn -->

## Screenshot (when possible)
![]()
