module.exports = {
  "extends": "eslint:recommended",
  "globals": {
    "self": false
  },
  "env": {
    "node": true
  },
  "rules": {
    'no-console': 'off'
  }
}