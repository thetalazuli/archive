module.exports = {
  context: {name: 'Mick', count: 30},
  handlebars: 'Hello {{name}}! You have {{count}} new messages.',
  dust: 'Hello {name}! You have {count} new messages.',
  mustache: 'Hello {{name}}! You have {{count}} new messages.',
  eco: 'Hello <%= @name %>! You have <%= @count %> new messages.'
};

