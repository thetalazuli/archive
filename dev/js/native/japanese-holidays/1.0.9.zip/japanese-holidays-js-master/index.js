var JapaneseHolidays = require('./lib/japanese-holidays.js');

module.exports = JapaneseHolidays;
