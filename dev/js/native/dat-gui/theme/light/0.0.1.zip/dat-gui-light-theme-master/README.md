# dat-gui-light-theme.css #

[http://brm.io/dat-gui-light-theme/](http://brm.io/dat-gui-light-theme/)

This is a light theme for [dat.gui](http://workshop.chromeexperiments.com/examples/gui/#1--Basic-Usage), that fits in a bit better with lighter designs.

You can see a demo of it in action on the [Matter.js](http://brm.io/matter-js/) page.

## Usage ##

Reference [dat.gui](http://workshop.chromeexperiments.com/examples/gui/#1--Basic-Usage) in your HTML as normal, then include `dat-gui-light-theme.css` and you're golden.