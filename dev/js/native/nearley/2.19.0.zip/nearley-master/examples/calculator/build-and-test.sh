../../bin/nearleyc.js arithmetic.ne -o grammar.js -e arithmetic
node calculator.js
