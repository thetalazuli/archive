export declare function subtle(): SubtleCrypto;
