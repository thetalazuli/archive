export function subtle() {
    return window.crypto.subtle || window.crypto.webkitSubtle;
}
//# sourceMappingURL=compat.js.map