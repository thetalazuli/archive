/* global mocha */

mocha.setup({
    ignoreLeaks: true,
    timeout: 5000
});