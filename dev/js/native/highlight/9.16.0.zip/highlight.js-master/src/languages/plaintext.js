/*
Language: plaintext
Author: Egor Rogov (e.rogov@postgrespro.ru)
Description: Plain text without any highlighting.
Category: common
*/

function(hljs) {
    return {
        disableAutodetect: true
    };
}
