require('../../../modules/core.string.escape-html');
module.exports = require('../../../modules/_entry-virtual')('String').escapeHTML;
