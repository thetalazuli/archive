require('../../modules/es6.object.to-string');
require('../../modules/web.dom.iterable');
require('../../modules/es6.weak-set');
require('../../modules/es7.weak-set.of');
require('../../modules/es7.weak-set.from');
module.exports = require('../../modules/_core').WeakSet;
