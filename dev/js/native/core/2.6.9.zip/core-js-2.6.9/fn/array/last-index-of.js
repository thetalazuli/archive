require('../../modules/es6.array.last-index-of');
module.exports = require('../../modules/_core').Array.lastIndexOf;
