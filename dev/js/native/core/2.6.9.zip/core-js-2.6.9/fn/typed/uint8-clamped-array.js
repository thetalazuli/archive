require('../../modules/es6.typed.uint8-clamped-array');
module.exports = require('../../modules/_core').Uint8ClampedArray;
