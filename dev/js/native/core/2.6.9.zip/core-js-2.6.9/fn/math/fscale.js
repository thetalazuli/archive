require('../../modules/es7.math.fscale');
module.exports = require('../../modules/_core').Math.fscale;
