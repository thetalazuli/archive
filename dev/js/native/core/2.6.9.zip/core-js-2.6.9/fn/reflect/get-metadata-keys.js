require('../../modules/es7.reflect.get-metadata-keys');
module.exports = require('../../modules/_core').Reflect.getMetadataKeys;
