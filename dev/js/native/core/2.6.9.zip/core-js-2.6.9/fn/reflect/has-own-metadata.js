require('../../modules/es7.reflect.has-own-metadata');
module.exports = require('../../modules/_core').Reflect.hasOwnMetadata;
