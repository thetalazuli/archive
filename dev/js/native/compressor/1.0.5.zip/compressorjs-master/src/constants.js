export const IN_BROWSER = typeof window !== 'undefined';
export const WINDOW = IN_BROWSER ? window : {};
