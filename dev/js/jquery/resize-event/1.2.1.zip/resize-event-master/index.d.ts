declare module "resize-event" {
  export default function onresize(target: HTMLElement, callback: () => void);
}
