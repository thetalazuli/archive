require("./lib/extensions/inputmask.extensions");
require("./lib/extensions/inputmask.date.extensions");
require("./lib/extensions/inputmask.numeric.extensions");
module.exports = require("./lib/inputmask.js");
