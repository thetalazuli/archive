module.exports = require("./dist/inputmask");
