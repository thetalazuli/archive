goldenlayout
============

The ultimate Javascript layout manager
