Free for non-commercial use only. License details to follow suit
