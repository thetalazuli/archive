
// Tracing.before('$', function(fnName, args, depth) { 
//     if(navigator.userAgent.indexOf("Chrome") !== -1){
//       var stack = new Error().stack
//       console.info(fnName, '{' + depth + '} args:', args, ' at:', stack.split("\n").splice(3).join("\n"))
//     } else {
//       console.log(fnName, '{' + depth + '} args:', args)
//     }    
// })
