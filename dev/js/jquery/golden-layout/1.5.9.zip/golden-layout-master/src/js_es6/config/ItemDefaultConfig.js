const itemDefaultConfig = {
    isClosable: true,
    reorderEnabled: true,
    title: ''
}

export default itemDefaultConfig
