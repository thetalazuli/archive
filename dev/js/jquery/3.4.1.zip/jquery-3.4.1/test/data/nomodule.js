QUnit.assert.ok( !QUnit.moduleTypeSupported, "evaluated: nomodule script with src" );
