QUnit.assert.ok( !QUnit.moduleTypeSupported, "evaluated: inner nomodule script with src" );
