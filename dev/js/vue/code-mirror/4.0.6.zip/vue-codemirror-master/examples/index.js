import example01 from './01-text-x-vue.vue'
import example02 from './02-text-javascript.vue'
import example03 from './03-text-css.vue'
import example04 from './04-text-html.vue'
import example05 from './05-application-x-httpd-php.vue'
import example06 from './06-python.vue'
import example07 from './07-text-apl.vue'
import example08 from './08-text-x-swift.vue'
import example09 from './09-text-x-go.vue'
import example10 from './10-text-x-lua.vue'
import example11 from './11-text-x-mysql.vue'
import example12 from './12-text-custom-mode.vue'
import example13 from './13-text-x-markdown.vue'
import example14 from './14-merge-view.vue'

export default {
  example01,
  example02,
  example03,
  example04,
  example05,
  example06,
  example07,
  example08,
  example09,
  example10,
  example11,
  example12,
  example13,
  example14
}
