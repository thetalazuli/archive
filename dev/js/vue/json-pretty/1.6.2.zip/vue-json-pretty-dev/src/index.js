import App from './components/app.vue'
import './assets/less/index.less'

export default Object.assign({}, App, {
  version: '1.6.2'
})
