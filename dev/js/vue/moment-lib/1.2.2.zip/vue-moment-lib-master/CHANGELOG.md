<a name="1.1.3"></a>
## [1.1.3](https://github.com/julon/vue-moment-lib/compare/v1.1.2...v1.1.3) (2018-06-02)


### Bug Fixes

* **filter:** add missing value param to filter ([cad2d57](https://github.com/julon/vue-moment-lib/commit/cad2d57))

<a name="1.1.2"></a>
## [1.1.2](https://github.com/julon/vue-moment-lib/compare/v1.1.1...v1.1.2) (2018-05-01)


### Bug Fixes

* **package:** bump package lock version ([cbe4207](https://github.com/julon/vue-moment-lib/commit/cbe4207))

<a name="1.1.1"></a>
## [1.1.1](https://github.com/julon/vue-moment-lib/compare/v1.1.0...v1.1.1) (2018-03-10)


### Bug Fixes

* add keywords to package.json ([22cfd9f](https://github.com/julon/vue-moment-lib/commit/22cfd9f))
* move publish to prepare ([b586183](https://github.com/julon/vue-moment-lib/commit/b586183))

<a name="1.1.0"></a>
# [1.1.0](https://github.com/julon/vue-moment-lib/compare/0cee3e9c80d7f6a4a84248edaa2ab48c001914fc...v1.1.0) (2018-01-21)


### Bug Fixes

* **docs:** fix extra argument ([421c13f](https://github.com/julon/vue-moment-lib/commit/421c13f))


### Features

* **component:** add component func $duration ([4cedf43](https://github.com/julon/vue-moment-lib/commit/4cedf43))

<a name="1.0.1"></a>
## [1.0.1](https://github.com/julon/vue-moment-lib/compare/48bee07613481a27473e3978a848805aa1c3d972...v1.0.1) (2018-01-20)


### Bug Fixes

* add docs for using global moments ([0cee3e9](https://github.com/julon/vue-moment-lib/commit/0cee3e9))

<a name="1.0.0"></a>
# 1.0.0 (2018-01-20)


### Features

* **moment:** add all moment library files ([74f7b19](https://github.com/julon/vue-moment-lib/commit/74f7b19))
