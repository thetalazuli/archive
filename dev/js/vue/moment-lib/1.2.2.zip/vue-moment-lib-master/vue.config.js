module.exports = {
  configureWebpack: {
    externals: {
      moment: "moment"
    }
  }
};
