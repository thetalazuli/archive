System.register([], function (_export) {
  return {
    exports: {
      dep: 'maptest'
    }
  };
});
