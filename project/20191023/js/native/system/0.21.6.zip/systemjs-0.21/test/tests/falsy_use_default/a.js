module.exports = require("./b.js");
