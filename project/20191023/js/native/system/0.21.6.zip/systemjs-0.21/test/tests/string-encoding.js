System.register([], function (_export) {
  _export('pi', 'π');
  _export('emoji', '🐶');
  return function () {};
});
