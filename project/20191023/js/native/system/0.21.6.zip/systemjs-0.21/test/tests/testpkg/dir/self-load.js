exports.a = require('..');
exports.b = require('../');