System.register(["./es6-loading-amd-dep.js"], function($__export) {
  "use strict";
  return {
    setters: [function(m) {
      $__export("amd", m.default);
    }],
    execute: function() {}
  };
});
