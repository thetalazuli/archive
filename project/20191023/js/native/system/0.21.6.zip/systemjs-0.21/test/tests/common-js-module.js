exports.first = require('./common-js-dep.js').output;
exports.hello = 'world';
