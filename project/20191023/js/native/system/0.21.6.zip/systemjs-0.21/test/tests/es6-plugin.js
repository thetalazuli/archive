export function fetch() {
  return 'module.exports = "plugin";';
}