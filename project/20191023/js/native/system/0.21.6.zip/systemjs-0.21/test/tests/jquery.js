System.register(['a'], function (_export) {
  return {
    setters: [function (m) {
      _export('default', m.A);
    }],
    execute: function () {}
  };
});
