exports.translate = function(load) {
  load.source += '\nexports.versionedPlugin = true;';
}