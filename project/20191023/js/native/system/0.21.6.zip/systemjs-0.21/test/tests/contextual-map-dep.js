System.register([], function (_export) {
  return {
    exports: {
      mapdep: 'mapdep'
    }
  };
});
