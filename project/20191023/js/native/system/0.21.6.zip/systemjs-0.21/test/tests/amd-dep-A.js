System.register([], function (_export) {
  this.A = 10;
  return {
    setters: [],
    execute: function () {
      _export('A', 10);
    }
  };
});
