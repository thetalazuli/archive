﻿define([], function () {
    // file starts with a byte order mark (BOM)
    return { amd: true };
});
