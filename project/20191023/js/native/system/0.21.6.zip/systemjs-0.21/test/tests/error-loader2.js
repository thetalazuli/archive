System.register(['non-existent'], function () {
  return function () {};
});
