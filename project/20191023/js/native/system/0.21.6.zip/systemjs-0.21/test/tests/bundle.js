define('bundle-define1', function() {
  return { name: 'bundle1' };
});

define('bundle-define2', function() {
  return { name: 'bundle2' };
});