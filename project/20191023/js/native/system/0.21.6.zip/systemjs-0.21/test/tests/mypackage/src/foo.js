file = 'foo'
if (typeof define != 'undefined')
  define({});
