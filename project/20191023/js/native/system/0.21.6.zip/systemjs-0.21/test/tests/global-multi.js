(function(window) {
  window.j$ = window.jjQuery = {
    jquery: 'here'
  };
})(typeof window != 'undefined' ? window : global);

