define('bundle-1', function() {
  return { defined: true };
});
define('bundle-2', function() {
  return { defined: true };
});
define('bundle-x/path/to/bundle-module-1', function() {
  return { defined: true };
});
define('bundle-x/path/to/bundle-module-2', function() {
  return { defined: true };
});