System.register([], function (_export) {
  "use strict";

  var c;
  return {
    setters: [],
    execute: function () {
      c = _export("c", function c() {
        babelHelpers.classCallCheck(this, c);

        babelHelpers.get(Object.getPrototypeOf(c.prototype), "constructor", this).call(this);
      });
      new c();
    }
  };
});