define(function () {
	return "Hello World";
});
