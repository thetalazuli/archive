System.register([], function (_export) {
  return {
    setters: [],
    execute: function () {
      _export('m', 'm');
    }
  };
})
