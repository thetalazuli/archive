System.register([], function (_export) {
  return {
    exports: {
      maptest: 'maptestsub'
    }
  };
});
