jjQuery = {
  v: '2.0..0'
};
another = {
  some: 'thing'
};