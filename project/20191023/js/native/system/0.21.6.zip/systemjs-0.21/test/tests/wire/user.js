module.exports = 'user';
