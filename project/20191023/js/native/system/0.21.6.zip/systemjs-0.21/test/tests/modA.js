define(function (require, exports, module) {
'use strict';

    var B = require("tests/lib/modB.js");
    var C = require("./modC.js");
    exports.A = "A";
});
