import { p } from './all-circular1.js';
export var a = 4;
p();