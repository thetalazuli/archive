module.exports = {
  nonce: 'abc'
};
