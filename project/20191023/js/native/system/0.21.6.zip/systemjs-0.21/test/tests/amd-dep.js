define({
  amd: 'dep'
});