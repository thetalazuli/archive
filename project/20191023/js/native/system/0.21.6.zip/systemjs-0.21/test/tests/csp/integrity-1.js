define(function () {
  return {
    integrity: 'integrity'
  }
});
