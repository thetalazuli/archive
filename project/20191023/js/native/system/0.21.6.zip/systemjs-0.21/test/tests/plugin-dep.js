System.register([], function($__export) {
  return {
    setters: [],
    execute: function() {
      $__export('p', 5);
    }
  };
});