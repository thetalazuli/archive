
 <template>
  <div class='sample'>
    <input type='text' v-model='db.params.select.id' placeholder='検索したいID'>
    <table class='ui table single line unstackable celled fixed very basic'>
      <thead>
        <th>C</th>
        <th>NO</th>
        <th>INC-ID</th>
        <th>INFORMATION</th>
     </thead>
      <tbody>
        <template v-for='(row,i) in db.table.DATA'>
          <tr>
            <td @click="$emit('remove',row[0],'sample',row,i)">
              <i class='icon remove'>
             </i>
           </td>
            <td>{{i}}</td>
            <td>{{row[0]}}</td>
            <td>
              <input 
                type='text'
                v-model='row[1]'
                @input="$emit('update',row[0],'sample',row,i)">
           </td>
         </tr>
       </template>
     </tbody>
   </table>
 </div>
</template>
 <script>
  module.exports={
    model:{
       prop:'db',
       event:'input'
     },
     props:{
       db:Object,
       default:null,
       required:true
     }
  }
</script>
 <style>
  .sample .ui.table>thead>tr>th:nth-child(1),
  .sample .ui.table>thead>tr>th:nth-child(2){
    width:3em;
  }
  .sample .ui.table>tbody>tr>td>i.icon{
    margin-right:0;
  }
  .sample .ui.table>thead>tr>th,
  .sample .ui.table>tbody>tr>td{
    text-align:center;
    padding:0;
  }
  .sample input{
    width:100%;
    border:none;
    outline:none;
    text-align:center;
  }
</style>
