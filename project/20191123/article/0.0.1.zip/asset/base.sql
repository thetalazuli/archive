create table sample(
  id int(11) not null auto_increment,
  information text not null,
  primary key (id)
);

insert into sample(
  information
)values(
  '営業'
);
insert into sample(
  information
)values(
  '保険'
);
insert into sample(
  information
)values(
  '管理'
);
